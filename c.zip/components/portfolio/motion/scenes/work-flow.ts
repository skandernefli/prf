import { gsap } from "gsap";

import { addFromTo, scrollTriggerDefaults } from "../motion-utils";

export function buildWorkFlowScene(root: HTMLElement) {
  const section = root.querySelector<HTMLElement>(".work-flow");
  if (!section) return;

  const copy = section.querySelector<HTMLElement>(".work-flow-copy");
  const headingLines = Array.from(
    section.querySelectorAll<HTMLElement>(".work-flow-copy h2 > span"),
  );

  // Title: one continuous x-drift across the whole section scroll.
  //  - Entry: starts offset on the opposite side, drifts toward 0.
  //  - "top top": x hits 0 exactly (its original place).
  //  - Exit: keeps going in the same direction to the other offset.
  // Single trigger + single ease = no boundary, no stop, no reversal.
  if (copy && headingLines.length === 3) {
    // Exit direction per line: 0 & 2 end on the right, 1 ends on the left.
    // Entry therefore starts on the opposite side (left for 0 & 2, right for 1).
    const driftDirections = [1, -1, 1];

    const EDGE_MARGIN = 24;
    const MAX_DRIFT = () => Math.min(window.innerWidth * 0.06, 72);

    // Room available on a given side (+1 = right, -1 = left), measured from
    // the element's *untransformed* box so refreshes don't compound.
    const roomOn = (el: HTMLElement, side: number) => {
      const currentX = Number(gsap.getProperty(el, "x")) || 0;
      const rect = el.getBoundingClientRect();
      const left = rect.left - currentX;
      const right = rect.right - currentX;
      const available =
        side > 0 ? window.innerWidth - EDGE_MARGIN - right : left - EDGE_MARGIN;
      return Math.max(0, Math.min(available, MAX_DRIFT()));
    };

    // Symmetric amplitude — the smaller of the two sides, so the line
    // travels equally far on either side of its resting position and
    // never crosses the edge margin.
    const drift = (el: HTMLElement) => Math.min(roomOn(el, 1), roomOn(el, -1));

    // Fraction of the section's scroll range at which "top top" occurs.
    let p0 = 0.5;

    // Piecewise-linear ease: 0 → 0.5 at p0 → 1. The tween's x midpoint (0)
    // therefore lands exactly at "top top", with no keyframe or pause.
    const ease = (p: number) =>
      p < p0 ? (p / p0) * 0.5 : 0.5 + ((p - p0) / (1 - p0)) * 0.5;

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: "top bottom",
        end: "bottom top",
        scrub: 0.6,
        invalidateOnRefresh: true,
        onRefresh: (self) => {
          const range = self.end - self.start;
          const raw = range > 0 ? window.innerHeight / range : 0.5;
          p0 = Math.max(0.08, Math.min(0.92, raw));
        },
      },
    });

    headingLines.forEach((line, i) => {
      const dir = driftDirections[i];
      tl.fromTo(
        line,
        // Start on the opposite side; end on the exit side. x = 0 at p0.
        { x: () => -dir * drift(line) },
        {
          x: () => dir * drift(line),
          ease,
          immediateRender: false,
        },
        0,
      );
    });

    // Blur reveal — once only, matches the labels' reveal in this section.
    // Separate, non-scrubbed tween so it plays through independent of the
    // scrubbed x-drift above (both touch different CSS props: filter vs x).
    // Fires when the section's top reaches 60% of the viewport — i.e. once
    // the title is clearly on screen, not just peeking in from the bottom.
    gsap.fromTo(
      headingLines,
      { filter: "blur(4px)" },
      {
        filter: "blur(0px)",
        duration: 0.45,
        ease: "power2.out",
        stagger: 0.08,
        scrollTrigger: {
          trigger: section,
          start: "top 30%",
          once: true,
        },
      },
    );
  }

  const description = section.querySelector<HTMLElement>(
    ".work-flow-description",
  );

  if (description) {
    const reveal = gsap.timeline({
      scrollTrigger: scrollTriggerDefaults(
        description,
        "top 50%",
        "top 40%",
        0.5,
      ),
    });

    addFromTo(
      reveal,
      description,
      { y: 18, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.65,
        ease: "power3.out",
      },
      0,
    );
  }

  const labels = section.querySelectorAll<HTMLElement>(".work-flow-label");

  labels.forEach((label) => {
    const reveal = gsap.timeline({
      scrollTrigger: scrollTriggerDefaults(label, "top 50%", "top 40%", 0.45),
    });

    addFromTo(
      reveal,
      label,
      { opacity: 0, filter: "blur(4px)" },
      {
        opacity: 1,
        filter: "blur(0px)",
        duration: 0.45,
        ease: "power2.out",
      },
      0,
    );
  });
}
